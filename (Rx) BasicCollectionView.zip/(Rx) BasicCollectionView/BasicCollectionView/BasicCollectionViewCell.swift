import UIKit

class BasicCollectionViewCell: UICollectionViewCell {
    @IBOutlet var label: UILabel!
}
